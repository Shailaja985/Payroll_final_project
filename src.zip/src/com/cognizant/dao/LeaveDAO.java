package com.cognizant.dao;

import com.cognizant.model.Employee;
import com.cognizant.exception.EmployeeException;

public interface LeaveDAO {
 
	public Employee getViewSalary(int empId) throws EmployeeException;
	
}