package com.cognizant.service;

import com.cognizant.model.Employee;

public interface LeaveService {

Employee getViewSalary(int empId);

}